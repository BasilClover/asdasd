package com.examples; //location of the main program, class (NYSE_example) in line 20 located in subdirectory 'examples' under the main directory 'com'
//import all neccessary functions, utilities and other sources required to perform the MR code
import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
//import ends
public class NYSE_example { //definition of Java class
	/*job uses (implements) Mapper, this ensures that in spite of the 
	different approaches to process data, the interface (input/output) 
	is in the same format*/
	public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, Text, LongWritable> {   
	    private Text ticker = new Text(); //MR uses this data type for strings 
	    private LongWritable trade_price = new LongWritable(1);//MR uses this data type for integers 
	    //mapper component started
	    public void map(LongWritable key, Text value, OutputCollector<Text, LongWritable> output, Reporter reporter) throws IOException {
				//input lines are read line by line as (byte_offest, value) pair
	    		String line = value.toString(); //each line is read as a string
				String[] tokens = line.split(","); //string is tokenized
				{
					//an appropriate schema of data to be processed is created
					ticker.set(tokens[0]); 							//first value of each line is assigned to the ticker
					trade_price.set(Long.parseLong(tokens[2])); 	//third value of the line is assigned to the trdae_price 
					output.collect(ticker, trade_price); 			//values are emitted through output.collect
				}
			}
	    } //mapper component finished
	
		//reducer component started
		/*extends to the MapReduce base implementing a standard reducer
		 * which allows the records that are sent to the reducer to have the standard 
		 * (key, value) pair format, similiar to the one emitted by the mapper*/
		public static class Reduce extends MapReduceBase implements Reducer<Text, LongWritable, Text, LongWritable> {  
			//the value is a list (array) that holds a set of trading prices for each ticker
		    public void reduce(Text key, Iterator<LongWritable> values, OutputCollector<Text, LongWritable> output, Reporter reporter) throws IOException {
		    	//processing of input
		    	long MaxPrice = 0; //starts with a MaxPrice = 0
		    	/*compares each element in the trade_price line with MaxPrice, 
		    	 * and if the trade_price is higher than the MaxPrice, 
		    	 * then the MaxPrice becomes equal to the trade_price.*/
		    	while (values.hasNext()) {
		        long next_price = values.next().get(); 
		        if (next_price > MaxPrice) MaxPrice = next_price ;
		      }
		      output.collect(key, new LongWritable(MaxPrice)); //the reducer emits the (key, MaxPrice) using output.collect
		    }
		  } //reducer component finished
		    
	  /*driver of the program started, define the structure of the MR job and controls the 
	  /interface of the program with input-output files and directories*/
	  public static void main(String[] args) throws Exception {
	    JobConf conf = new JobConf(NYSE_example.class); //define the job asa variable 'conf' of JobConfType and assign value of class name to it
	    conf.setJobName("NYSE"); //JobName of the variable is assigned to value 'NYSE', used to call the mR job during execution phase
		conf.setOutputKeyClass(Text.class); //assign specific data types to output key of the conf job
	    conf.setOutputValueClass(LongWritable.class); //assign specific data types to the output value of the conf job
		conf.setMapperClass(Map.class); //assign 'Map' class to the mapper of the conf
	    conf.setReducerClass(Reduce.class); //assign 'Reduce' class to the reducer of the conf
		conf.setInputFormat(TextInputFormat.class); //define the format to input files
	    conf.setOutputFormat(TextOutputFormat.class); //define the format of the output files

	    FileInputFormat.setInputPaths(conf, new Path(args[0])); //define path to the input file
	    FileOutputFormat.setOutputPath(conf, new Path(args[1])); //define path to the output file

	    JobClient.runJob(conf); //call job 'conf' to run
	  } //driver of the program finished

}
